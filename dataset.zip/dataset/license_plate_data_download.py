"""Module providing a script to install dataset for licenseplate segmentation"""

import os
import gdown

FILE_ID = '1Ep2jvhz8ontuLRGi90UYx67NNl0WOT7p'
OUTPUT = 'dataset/licenseplate_data.zip'
URL = f'https://drive.google.com/uc?id={FILE_ID}'

# Check if the file already exists
if not os.path.exists(OUTPUT):
    print("File does not exist. Downloading...")
    gdown.download(URL, OUTPUT, quiet=False)
else:
    print("File already exists. Skipping download.")
