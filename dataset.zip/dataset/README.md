## How to download dataset for licenseplate segmentation

Run the following command from root folder.

```bash
python dataset/license_plate_data_download.py
```

After the command has completed the file should be in the dataset folder with the filename: license_plate_dataset.zip. Unpack the zip-file with the following command.

```bash
unzip dataset/license_plate_data_download.py
```

